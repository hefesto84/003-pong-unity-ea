﻿namespace Pong.Core.Enums
{
    public enum SoundType
    {
        Wall,
        Paddle,
        Result
    }
}