﻿using Pong.Core.Enums;

namespace Pong.Core.Models
{
    public class ScoreEntry
    {
        public PlayerType PlayerType { get; set; }
        public int Score { get; set; }
    }
}