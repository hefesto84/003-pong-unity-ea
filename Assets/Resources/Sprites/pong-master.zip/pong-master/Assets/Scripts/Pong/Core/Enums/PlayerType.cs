﻿namespace Pong.Core.Enums
{
    public enum PlayerType
    {
        Player,
        Opponent,
        None
    }
}