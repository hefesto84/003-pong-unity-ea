# Pong

This game has no physics nor colliders.

![Sin título](https://user-images.githubusercontent.com/9928578/167951607-713d17c8-e4c6-431d-9d1e-02e87b2761e3.png)
